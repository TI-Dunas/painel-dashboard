"""Inicia o painel em HTTPS na MESMA porta de sempre (8080).

Certificado (em /data/certs):
  * cert.pem + key.pem existentes: sao usados como estao (ex.: o certificado curinga
    *.grupovia.lan copiado por usar-certificado-glpi.sh / criar-certificado-interno.sh).
  * Se nao existirem: o painel cria uma AUTORIDADE CERTIFICADORA interna (data/certs/ca.crt,
    gerada uma unica vez e reaproveitada) e emite com ela um certificado para PAINEL_HOSTS.

Porta unica: quem digitar http://servidor:8080 (favoritos antigos, ou o navegador sem "https://")
recebe um redirecionamento para https://servidor:8080. O primeiro byte da conexao diz se e TLS
(0x16) ou HTTP comum; as conexoes TLS seguem para o uvicorn, que roda so dentro do conteiner.
"""
import asyncio
import datetime
import fnmatch
import ipaddress
import os
import re
import threading

import uvicorn

DATA_DIR = os.environ.get("DATA_DIR", "/data")
PASTA_CERT = os.path.join(DATA_DIR, "certs")
CERT = os.path.join(PASTA_CERT, "cert.pem")
CHAVE = os.path.join(PASTA_CERT, "key.pem")
CA_CERT = os.path.join(PASTA_CERT, "ca.crt")
CA_CHAVE = os.path.join(PASTA_CERT, "ca.key")
PORTA = int(os.environ.get("PORTA", "8080"))                      # porta escutada no conteiner
PORTA_PUBLICA = os.environ.get("PORTA_PUBLICA", str(PORTA))        # porta usada no redirecionamento
PORTA_INTERNA = int(os.environ.get("PORTA_INTERNA", "8443"))       # uvicorn (so em 127.0.0.1)
HOSTS = [h.strip() for h in os.environ.get("PAINEL_HOSTS", "localhost").split(",") if h.strip()]
ORG = "Painel de Atendimento GLPI"
DIAS_AVISO = 30


def _gravar(caminho, dados, privado=False):
    os.makedirs(PASTA_CERT, exist_ok=True)
    novo = caminho + ".novo"
    with open(novo, "wb") as f:
        f.write(dados)
    if privado:
        os.chmod(novo, 0o600)
    os.replace(novo, caminho)


def _carregar_ou_criar_ca():
    """Reaproveita a CA interna (para nao ter de redistribuir) ou cria uma nova."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID

    if os.path.exists(CA_CERT) and os.path.exists(CA_CHAVE):
        ca = x509.load_pem_x509_certificate(open(CA_CERT, "rb").read())
        chave = serialization.load_pem_private_key(open(CA_CHAVE, "rb").read(), password=None)
        pub = serialization.PublicFormat.SubjectPublicKeyInfo
        if (ca.public_key().public_bytes(serialization.Encoding.PEM, pub)
                == chave.public_key().public_bytes(serialization.Encoding.PEM, pub)):
            return ca, chave
        print("ATENCAO: data/certs/ca.key nao corresponde a data/certs/ca.crt.", flush=True)
    elif os.path.exists(CA_CERT):
        print("ATENCAO: data/certs/ca.crt existe, mas a chave da CA nao esta aqui (ela fica em "
              "/etc/pki/grupovia-ca quando se usa criar-certificado-interno.sh). Criando uma CA NOVA: "
              "ela tera de ser distribuida de novo. Para evitar, rode ./criar-certificado-interno.sh.", flush=True)

    chave = rsa.generate_private_key(public_exponent=65537, key_size=4096)
    nome = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, f"{ORG} - CA interna"),
                      x509.NameAttribute(NameOID.ORGANIZATION_NAME, ORG)])
    agora = datetime.datetime.now(datetime.timezone.utc)
    ski = x509.SubjectKeyIdentifier.from_public_key(chave.public_key())
    ca = (x509.CertificateBuilder()
          .subject_name(nome).issuer_name(nome).public_key(chave.public_key())
          .serial_number(x509.random_serial_number())
          .not_valid_before(agora - datetime.timedelta(minutes=5))
          .not_valid_after(agora + datetime.timedelta(days=3650))
          .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
          .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True,
                                       content_commitment=False, key_encipherment=False,
                                       data_encipherment=False, key_agreement=False,
                                       encipher_only=False, decipher_only=False), critical=True)
          .add_extension(ski, critical=False)
          .sign(chave, hashes.SHA256()))
    _gravar(CA_CHAVE, chave.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                          serialization.NoEncryption()), privado=True)
    _gravar(CA_CERT, ca.public_bytes(serialization.Encoding.PEM))
    print(f"CA interna criada: {CA_CERT} (distribua este arquivo por GPO)", flush=True)
    return ca, chave


def gerar_certificado():
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

    ca, ca_chave = _carregar_ou_criar_ca()
    chave = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    nomes = []
    for h in HOSTS + ["localhost"]:
        try:
            nomes.append(x509.IPAddress(ipaddress.ip_address(h)))
        except ValueError:
            nomes.append(x509.DNSName(h))
    agora = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder()
            .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, HOSTS[0]),
                                     x509.NameAttribute(NameOID.ORGANIZATION_NAME, ORG)]))
            .issuer_name(ca.subject).public_key(chave.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(agora - datetime.timedelta(minutes=5))
            .not_valid_after(agora + datetime.timedelta(days=825))
            .add_extension(x509.SubjectAlternativeName(list(dict.fromkeys(nomes))), critical=False)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.KeyUsage(digital_signature=True, key_encipherment=True,
                                         content_commitment=False, data_encipherment=False,
                                         key_agreement=False, key_cert_sign=False, crl_sign=False,
                                         encipher_only=False, decipher_only=False), critical=True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
            .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_chave.public_key()),
                           critical=False)
            .sign(ca_chave, hashes.SHA256()))
    _gravar(CHAVE, chave.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                                       serialization.NoEncryption()), privado=True)
    _gravar(CERT, cert.public_bytes(serialization.Encoding.PEM))
    print(f"Certificado gerado pela CA interna para: {', '.join(HOSTS)} (valido por 825 dias)", flush=True)


def _nomes_do_cert(c):
    from cryptography import x509
    try:
        san = c.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    except x509.ExtensionNotFound:
        return [], []
    return san.get_values_for_type(x509.DNSName), [str(i) for i in san.get_values_for_type(x509.IPAddress)]


def _cobre(host, dns, ips):
    try:
        return str(ipaddress.ip_address(host)) in ips
    except ValueError:
        pass
    host = host.lower()
    for n in dns:
        n = n.lower()
        if n == host:
            return True
        # curinga vale para UM nivel: *.grupovia.lan cobre helpdesk.grupovia.lan
        if n.startswith("*.") and host.count(".") == n.count(".") and fnmatch.fnmatchcase(host, n):
            return True
    return False


def _autogerado_antigo(c):
    """Certificado autoassinado das versoes anteriores (sem CA): o navegador nunca confia nele."""
    from cryptography.x509.oid import NameOID
    org = c.subject.get_attributes_for_oid(NameOID.ORGANIZATION_NAME)
    return c.issuer == c.subject and bool(org) and org[0].value == ORG


def conferir_certificado():
    """Mostra no log qual certificado esta em uso e avisa sobre problemas comuns."""
    from cryptography import x509
    c = x509.load_pem_x509_certificate(open(CERT, "rb").read())
    if _autogerado_antigo(c):
        print("Certificado autoassinado antigo encontrado: trocando por um emitido pela CA interna.", flush=True)
        gerar_certificado()
        c = x509.load_pem_x509_certificate(open(CERT, "rb").read())
    dns, ips = _nomes_do_cert(c)
    fim = c.not_valid_after_utc
    print(f"  emitido para: {c.subject.rfc4514_string()}", flush=True)
    print(f"  nomes (SAN):  {', '.join(dns + ips) or '(nenhum)'}", flush=True)
    print(f"  emissor:      {c.issuer.rfc4514_string()}", flush=True)
    print(f"  valido ate:   {fim:%d/%m/%Y}", flush=True)
    faltando = [h for h in HOSTS if not _cobre(h, dns, ips)]
    if faltando:
        print(f"  ATENCAO: o certificado nao cobre {', '.join(faltando)}. Acessar por esse(s) "
              "endereco(s) dara aviso no navegador.", flush=True)
    restam = (fim - datetime.datetime.now(datetime.timezone.utc)).days
    if restam < 0:
        print("  ATENCAO: o certificado esta VENCIDO.", flush=True)
    elif restam <= DIAS_AVISO:
        print(f"  ATENCAO: o certificado vence em {restam} dia(s).", flush=True)
    if c.issuer == c.subject:
        print("  ATENCAO: certificado autoassinado. Os navegadores so confiam nele se ele mesmo for "
              "instalado como raiz confiavel. Prefira um emitido por CA (veja o LEIAME).", flush=True)
    if os.path.exists(CA_CERT):
        print("  CA interna para distribuir (GPO): data/certs/ca.crt", flush=True)


# ------------------------------------------------------------------ porta unica (HTTP -> HTTPS)
HOST_VALIDO = re.compile(r"^[A-Za-z0-9.\-]+$|^\[[0-9A-Fa-f:.]+\]$")


async def _copiar(origem, destino):
    try:
        while True:
            bloco = await origem.read(65536)
            if not bloco:
                break
            destino.write(bloco)
            await destino.drain()
    except (ConnectionError, OSError, asyncio.CancelledError):
        pass
    finally:
        try:
            if destino.can_write_eof():
                destino.write_eof()
        except (OSError, RuntimeError):
            pass


def _fechar(*escritores):
    for w in escritores:
        try:
            w.close()
        except (OSError, RuntimeError):
            pass


async def _redirecionar(primeiro, leitor, escritor):
    dados = primeiro
    try:
        while b"\r\n\r\n" not in dados and len(dados) < 8192:
            bloco = await asyncio.wait_for(leitor.read(4096), 5)
            if not bloco:
                break
            dados += bloco
    except asyncio.TimeoutError:
        pass
    linhas = dados.split(b"\r\n")
    partes = linhas[0].decode("latin-1", "replace").split(" ")
    caminho = partes[1] if len(partes) >= 2 and partes[1].startswith("/") else "/"
    host = HOSTS[0]
    for linha in linhas[1:]:
        nome, _, valor = linha.decode("latin-1", "replace").partition(":")
        if nome.strip().lower() == "host":
            valor = valor.strip()
            h = valor[:valor.index("]") + 1] if valor.startswith("[") and "]" in valor else valor.split(":")[0]
            if HOST_VALIDO.match(h):
                host = h
            break
    destino = f"https://{host}:{PORTA_PUBLICA}{caminho}"
    corpo = f'<a href="{destino}">{destino}</a>'.encode()
    escritor.write((f"HTTP/1.1 301 Moved Permanently\r\nLocation: {destino}\r\n"
                    f"Content-Type: text/html; charset=utf-8\r\nContent-Length: {len(corpo)}\r\n"
                    "Connection: close\r\n\r\n").encode() + corpo)
    try:
        await escritor.drain()
    except (ConnectionError, OSError):
        pass


async def _atender(leitor, escritor):
    try:
        primeiro = await asyncio.wait_for(leitor.read(1), 30)
    except (asyncio.TimeoutError, ConnectionError, OSError):
        _fechar(escritor)
        return
    if not primeiro:
        _fechar(escritor)
        return
    if primeiro[0] != 0x16:                       # nao e TLS: HTTP comum
        await _redirecionar(primeiro, leitor, escritor)
        _fechar(escritor)
        return
    try:
        l2, e2 = await asyncio.open_connection("127.0.0.1", PORTA_INTERNA)
    except OSError:
        _fechar(escritor)
        return
    e2.write(primeiro)
    await asyncio.gather(_copiar(leitor, e2), _copiar(l2, escritor))
    _fechar(e2, escritor)


def porta_unica():
    async def principal():
        servidor = await asyncio.start_server(_atender, "0.0.0.0", PORTA, backlog=512)
        async with servidor:
            await servidor.serve_forever()
    asyncio.run(principal())


if __name__ == "__main__":
    if not (os.path.exists(CERT) and os.path.exists(CHAVE)):
        gerar_certificado()
    else:
        print("Usando o certificado existente em", PASTA_CERT, flush=True)
    try:
        conferir_certificado()
    except Exception as e:  # noqa: BLE001
        print("  (não foi possível ler os dados do certificado:", e, ")", flush=True)
    threading.Thread(target=porta_unica, daemon=True).start()
    print(f"Painel em HTTPS na porta {PORTA} (http:// nessa porta e redirecionado para https://)", flush=True)
    uvicorn.run("main:app", host="127.0.0.1", port=PORTA_INTERNA, ssl_certfile=CERT, ssl_keyfile=CHAVE,
                log_level="warning", timeout_keep_alive=15)
