"""Painel de Atendimento GLPI - servidor web."""
import base64
import csv
import io
import json
import os
import secrets
import threading
import time
from datetime import datetime

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

import glpi
import metrics
from usuarios import PAPEIS, ErroUsuario, Usuarios

DATA_DIR = os.environ.get("DATA_DIR", "/data")
ARQ_CONFIG = os.path.join(DATA_DIR, "config.json")
ARQ_PAINEL = os.path.join(DATA_DIR, "dashboard.json")
STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
FOTOS = os.path.join(DATA_DIR, "fotos")

PANEL_USER = os.environ.get("PANEL_USER", "admin")
PANEL_PASSWORD = os.environ.get("PANEL_PASSWORD", "")

CONFIG_PADRAO = {
    "glpi_url": "",
    "app_token": "",
    "user_token": "",
    "verify_ssl": False,
    "tech_profile": "Technician",
    "cache_minutes": 10,
    "timeout": 90,
    "retries": 3,
    **metrics.RANKING_PADRAO,
}
LIMITES_RANKING = {  # campo: (minimo, maximo)
    "rk_peso_sla": (0, 100), "rk_peso_reab": (0, 100), "rk_peso_pend": (0, 100), "rk_peso_sol": (0, 100),
    "rk_limite_reab": (1, 100), "rk_limite_pend_h": (1, 720), "rk_limite_sol_h": (1, 720), "rk_minimo": (1, 100),
}

COOKIE = "painel_sessao"
usuarios = Usuarios(DATA_DIR)
usuarios.garantir_admin_inicial(PANEL_USER, PANEL_PASSWORD)


def usuario_atual(request: Request):
    u = usuarios.ler_sessao(request.cookies.get(COOKIE, ""))
    if not u:
        raise HTTPException(401, "Sessão expirada. Entre novamente.")
    return u


def somente_admin(u: dict = Depends(usuario_atual)):
    if u["role"] != "admin":
        raise HTTPException(403, "Apenas administradores podem fazer isso.")
    return u


app = FastAPI(title="Painel GLPI")
app.mount("/static", StaticFiles(directory=STATIC), name="static")


# ------------------------------------------------------------------ arquivos
def ler_json(caminho, padrao):
    try:
        with open(caminho, encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return padrao


def gravar_json(caminho, dados):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = caminho + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)
    os.replace(tmp, caminho)


def ler_config():
    cfg = dict(CONFIG_PADRAO)
    cfg.update(ler_json(ARQ_CONFIG, {}))
    return cfg


# ------------------------------------------------------------------ cache
CACHE = {"dados": None, "ts": 0.0, "carregado_em": None, "falha_ts": 0.0, "falha": ""}
TRAVA = threading.Lock()
ESPERA_APOS_FALHA = 120  # segundos sem nova tentativa depois que o GLPI falha


def obter_dados(forcar=False):
    cfg = ler_config()
    with TRAVA:
        agora = time.time()
        validade = max(1, int(cfg.get("cache_minutes") or 10)) * 60
        tem_dados = CACHE["dados"] is not None
        if tem_dados and not forcar and agora - CACHE["ts"] < validade:
            return CACHE["dados"]
        # GLPI falhou ha pouco: mostra os ultimos dados sem insistir a cada clique
        if tem_dados and not forcar and agora - CACHE["falha_ts"] < ESPERA_APOS_FALHA:
            return CACHE["dados"]
        try:
            dados = glpi.carregar(cfg)
        except Exception as e:  # noqa: BLE001
            CACHE.update(falha_ts=agora, falha=str(e))
            if tem_dados:
                return CACHE["dados"]  # dados antigos continuam na tela, com aviso
            raise
        CACHE.update(dados=dados, ts=agora, carregado_em=datetime.now(), falha_ts=0.0, falha="")
        return dados


def aviso_dados():
    """Mensagem para a tela quando os dados exibidos sao de uma leitura anterior."""
    if CACHE["falha"] and CACHE["carregado_em"]:
        return (f"{CACHE['falha']} Exibindo os últimos dados disponíveis, de "
                f"{CACHE['carregado_em'].strftime('%d/%m/%Y %H:%M')}. O painel tentará de novo em alguns minutos.")
    return ""


def limpar_cache():
    with TRAVA:
        CACHE.update(dados=None, ts=0.0, carregado_em=None, falha_ts=0.0, falha="")


# ------------------------------------------------------------------ rotas
@app.get("/")
def index(request: Request):
    if not usuarios.ler_sessao(request.cookies.get(COOKIE, "")):
        return RedirectResponse("/login", status_code=303)
    return FileResponse(os.path.join(STATIC, "index.html"))


@app.get("/tecnico")
def pagina_tecnico(request: Request):
    if not usuarios.ler_sessao(request.cookies.get(COOKIE, "")):
        return RedirectResponse("/login", status_code=303)
    return FileResponse(os.path.join(STATIC, "tecnico.html"))


@app.get("/ranking")
def pagina_ranking(request: Request):
    if not usuarios.ler_sessao(request.cookies.get(COOKIE, "")):
        return RedirectResponse("/login", status_code=303)
    return FileResponse(os.path.join(STATIC, "ranking.html"))


@app.get("/login")
def pagina_login():
    return FileResponse(os.path.join(STATIC, "login.html"))


@app.post("/api/login")
def api_login(dados: dict, request: Request, response: Response):
    u = usuarios.autenticar(str(dados.get("username", "")).strip(), str(dados.get("password", "")))
    if not u:
        time.sleep(1)
        raise HTTPException(401, "Usuário ou senha incorretos.")
    response.set_cookie(COOKIE, usuarios.criar_sessao(u["username"]), httponly=True,
                        samesite="lax", secure=request.url.scheme == "https", max_age=int(os.environ.get("SESSION_HOURS", "12")) * 3600)
    return u


@app.post("/api/logout")
def api_logout(response: Response):
    response.delete_cookie(COOKIE)
    return {"ok": True}


@app.get("/api/me")
def api_eu(u: dict = Depends(usuario_atual)):
    return u


@app.post("/api/me/password")
def api_minha_senha(dados: dict, u: dict = Depends(usuario_atual)):
    if not usuarios.autenticar(u["username"], str(dados.get("current", ""))):
        raise HTTPException(400, "A senha atual está incorreta.")
    try:
        usuarios.alterar(u["username"], senha=str(dados.get("new", "")))
    except ErroUsuario as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


# ------------------------------------------------------------------ usuarios (admin)
@app.get("/api/users")
def api_usuarios(_: dict = Depends(somente_admin)):
    return {"users": usuarios.listar(), "roles": PAPEIS}


@app.post("/api/users")
def api_usuario_criar(dados: dict, _: dict = Depends(somente_admin)):
    try:
        usuarios.criar(str(dados.get("username", "")).strip(), str(dados.get("name", "")),
                       dados.get("role", "admin"), str(dados.get("password", "")))
    except ErroUsuario as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@app.put("/api/users/{username}")
def api_usuario_alterar(username: str, dados: dict, _: dict = Depends(somente_admin)):
    try:
        usuarios.alterar(username, nome=dados.get("name"), papel=dados.get("role"),
                         senha=str(dados.get("password") or "") or None)
    except ErroUsuario as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@app.delete("/api/users/{username}")
def api_usuario_remover(username: str, u: dict = Depends(somente_admin)):
    try:
        usuarios.remover(username, u["username"])
    except ErroUsuario as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@app.get("/api/config")
def api_config(_: dict = Depends(usuario_atual)):
    cfg = ler_config()
    return {
        "glpi_url": cfg["glpi_url"],
        "verify_ssl": cfg["verify_ssl"],
        "tech_profile": cfg["tech_profile"],
        "cache_minutes": cfg["cache_minutes"],
        "timeout": cfg["timeout"],
        "retries": cfg["retries"],
        "app_token_set": bool(cfg["app_token"]),
        "user_token_set": bool(cfg["user_token"]),
        "configured": bool(cfg["glpi_url"] and cfg["user_token"]),
        **{k: cfg[k] for k in metrics.RANKING_PADRAO},
    }


def mesclar(novo):
    cfg = ler_config()
    for campo in ("glpi_url", "tech_profile"):
        if campo in novo:
            cfg[campo] = str(novo[campo] or "").strip()
    for campo in ("app_token", "user_token"):  # vazio = manter o atual
        valor = str(novo.get(campo) or "").strip()
        if valor:
            cfg[campo] = valor
    if novo.get("clear_app_token"):
        cfg["app_token"] = ""
    if "verify_ssl" in novo:
        cfg["verify_ssl"] = bool(novo["verify_ssl"])
    faixas = (("cache_minutes", 1, 1440), ("timeout", 10, 600), ("retries", 1, 5)) + tuple(
        (k, a, b) for k, (a, b) in LIMITES_RANKING.items())
    for campo, minimo, maximo in faixas:
        if campo in novo:
            try:
                cfg[campo] = min(maximo, max(minimo, int(novo[campo])))
            except (TypeError, ValueError):
                pass
    pesos = ("rk_peso_sla", "rk_peso_reab", "rk_peso_pend", "rk_peso_sol")
    if not any(cfg[k] for k in pesos):
        cfg.update({k: metrics.RANKING_PADRAO[k] for k in pesos})
    cfg["glpi_url"] = glpi.normalizar_url(cfg["glpi_url"])
    return cfg


@app.post("/api/config")
def api_config_salvar(novo: dict, u: dict = Depends(somente_admin)):
    gravar_json(ARQ_CONFIG, mesclar(novo))
    limpar_cache()
    return api_config(u)


@app.post("/api/test")
def api_testar(novo: dict, _: dict = Depends(somente_admin)):
    try:
        return {"ok": True, "message": glpi.testar(mesclar(novo))}
    except glpi.GlpiError as e:
        return {"ok": False, "message": str(e)}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "message": f"Erro inesperado: {e}"}


@app.get("/api/metric-list")
def api_metricas(_: dict = Depends(usuario_atual)):
    return metrics.METRICS


def ler_filtros(start, end, techs):
    try:
        inicio = datetime.strptime(start, "%Y-%m-%d")
        fim = datetime.strptime(end, "%Y-%m-%d").replace(hour=23, minute=59, second=59)
    except ValueError:
        raise HTTPException(400, "Datas inválidas (use AAAA-MM-DD).")
    return inicio, fim, [int(x) for x in techs.split(",") if x.strip().isdigit()]


def dados_ou_erro(forcar=False):
    try:
        return obter_dados(forcar=forcar)
    except glpi.GlpiError as e:
        raise HTTPException(502, str(e))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(502, f"Erro ao consultar o GLPI: {e}")


@app.get("/api/export/chamados.csv")
def api_exportar_chamados(start: str, end: str, techs: str = "", _: dict = Depends(usuario_atual)):
    inicio, fim, ids = ler_filtros(start, end, techs)
    linhas = metrics.linhas_chamados(dados_ou_erro(), inicio, fim, ids)
    saida = io.StringIO()
    saida.write("\ufeff")  # BOM: o Excel reconhece os acentos
    escritor = csv.writer(saida, delimiter=";", lineterminator="\r\n")
    escritor.writerow(metrics.COLUNAS_CHAMADOS)
    for linha in linhas:
        escritor.writerow([str(v).replace(".", ",") if isinstance(v, float) else v for v in linha])
    nome = f"chamados_{start}_a_{end}.csv"
    return Response(saida.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{nome}"'})


@app.get("/api/data")
def api_dados(start: str, end: str, techs: str = "", refresh: bool = False,
              _: dict = Depends(usuario_atual)):
    inicio, fim, ids = ler_filtros(start, end, techs)
    dados = dados_ou_erro(refresh)
    lista = sorted(dados["techs"].values(), key=lambda u: u["name"].lower())
    return {
        "loaded_at": CACHE["carregado_em"].strftime("%d/%m/%Y %H:%M") if CACHE["carregado_em"] else "",
        "warning": aviso_dados(),
        "techs": lista,
        "metrics": metrics.calcular(dados, inicio, fim, ids, ler_config()),
    }


def w(metric, type_, width, height="M", title=None, palette="padrao", legend=True, values=False):
    meta = next(x for x in metrics.METRICS if x["id"] == metric)
    return {"id": secrets.token_hex(4), "metric": metric, "type": type_, "width": width,
            "height": height, "title": title or meta["title"], "palette": palette,
            "legend": legend, "values": values}


def widgets_ranking():
    return [
        w("ranking_tecnicos", "table", 12, "M"),
        w("ranking_pontuacao", "barh", 6, palette="verde", legend=False, values=True),
        w("ranking_notas", "bar", 6, palette="padrao"),
    ]


def widgets_pendencias():
    return [
        w("kpi_pendencia_media", "card", 3, "P", palette="quente"),
        w("kpi_pendencia_maior", "card", 3, "P", palette="alerta"),
        w("kpi_pendencia_total", "card", 3, "P", palette="quente"),
        w("kpi_pendentes_7dias", "card", 3, "P", palette="alerta"),
        w("pendencia_faixas", "bar", 6, palette="semaforo", legend=False, values=True),
        w("pendencia_soma_por_tecnico", "barh", 6, palette="quente", legend=False, values=True),
        w("tabela_pendencia_tecnico", "table", 12, "M"),
        w("tabela_pendentes", "table", 12, "G"),
    ]


def painel_padrao():
    return {"pendencias_v1": True, "ranking_v1": True, "widgets": [
        w("kpi_abertos", "card", 3, "P", palette="padrao"),
        w("kpi_em_aberto", "card", 3, "P", palette="azul"),
        w("kpi_pendentes", "card", 3, "P", palette="quente"),
        w("kpi_aguardando", "card", 3, "P", palette="pastel"),
        w("kpi_sla_expirado", "card", 3, "P", palette="alerta"),
        w("kpi_fechados", "card", 3, "P", palette="verde"),
        w("kpi_reabertos", "card", 3, "P", palette="quente"),
        w("kpi_sla_percentual", "card", 3, "P", palette="verde"),
        w("status_geral", "doughnut", 4, palette="semaforo", values=True),
        w("sla_geral", "pie", 4, palette="semaforo", values=True),
        w("em_aberto_por_tecnico", "barh", 4, legend=False, values=True),
        w("status_por_tecnico", "stacked", 6, palette="semaforo"),
        w("sla_por_tecnico", "barh_stacked", 6, palette="semaforo"),
        w("evolucao", "line", 12, palette="semaforo"),
        w("reabertos_por_tecnico", "bar", 6, palette="quente", legend=False, values=True),
        w("tempo_medio_por_tecnico", "barh", 6, palette="azul", legend=False, values=True),
        w("tabela_ranking", "table", 12, "M"),
    ] + widgets_ranking() + [
        w("tabela_sla_expirado", "table", 12, "G"),
    ] + widgets_pendencias()}


@app.get("/api/dashboard")
def api_painel(default: bool = False, _: dict = Depends(usuario_atual)):
    if default:
        return painel_padrao()
    painel = ler_json(ARQ_PAINEL, None)
    if not painel:
        return painel_padrao()
    if not painel.get("pendencias_v1"):
        # painel personalizado antes desta versao: acrescenta o bloco de pendencias uma unica vez
        painel["widgets"] = painel.get("widgets", []) + widgets_pendencias()
        painel["pendencias_v1"] = True
        gravar_json(ARQ_PAINEL, painel)
    if not painel.get("ranking_v1"):
        # acrescenta o ranking de tecnicos uma unica vez (depois pode ser movido ou removido)
        painel["widgets"] = painel.get("widgets", []) + widgets_ranking()
        painel["ranking_v1"] = True
        gravar_json(ARQ_PAINEL, painel)
    return painel


@app.post("/api/dashboard")
def api_painel_salvar(painel: dict, _: dict = Depends(somente_admin)):
    if not isinstance(painel.get("widgets"), list):
        raise HTTPException(400, "Formato invalido.")
    gravar_json(ARQ_PAINEL, painel)
    return {"ok": True}


# ------------------------------------------------------------------ pagina "por tecnico"
def caminho_foto(uid: int):
    return os.path.join(FOTOS, f"{int(uid)}.jpg")


def versao_foto(uid: int):
    try:
        return int(os.path.getmtime(caminho_foto(uid)))
    except OSError:
        return None


@app.get("/api/tecnicos")
def api_tecnicos(_: dict = Depends(usuario_atual)):
    dados = dados_ou_erro()
    lista = sorted(dados["techs"].values(), key=lambda u: u["name"].lower())
    return {"loaded_at": CACHE["carregado_em"].strftime("%d/%m/%Y %H:%M") if CACHE["carregado_em"] else "",
            "warning": aviso_dados(),
            "techs": [{**t, "foto": versao_foto(t["id"])} for t in lista]}


@app.get("/api/ranking")
def api_ranking(start: str, end: str, techs: str = "", _: dict = Depends(usuario_atual)):
    inicio, fim, ids = ler_filtros(start, end, techs)
    dados = dados_ou_erro()
    rk = metrics.ranking(dados, inicio, fim, ids, ler_config())
    for r in rk["ranking"]:
        r["foto"] = versao_foto(r["id"])
    return {"loaded_at": CACHE["carregado_em"].strftime("%d/%m/%Y %H:%M") if CACHE["carregado_em"] else "",
            "warning": aviso_dados(), **rk}


@app.get("/api/tecnico/{uid}")
def api_tecnico(uid: int, start: str, end: str, _: dict = Depends(usuario_atual)):
    inicio, fim, _ids = ler_filtros(start, end, "")
    dados = dados_ou_erro()
    if uid not in dados["techs"]:
        raise HTTPException(404, "Técnico não encontrado no GLPI.")
    resumo = metrics.resumo_por_tecnico(dados, inicio, fim)
    ativos = [u for u, t in dados["techs"].items() if t["active"]]
    cfg = ler_config()
    m = metrics.calcular(dados, inicio, fim, [uid], cfg)
    rk = metrics.ranking(dados, inicio, fim, None, cfg)
    meu = next((r for r in rk["ranking"] if r["id"] == uid), None)
    return {
        "loaded_at": CACHE["carregado_em"].strftime("%d/%m/%Y %H:%M") if CACHE["carregado_em"] else "",
        "warning": aviso_dados(),
        "tech": {**dados["techs"][uid], "foto": versao_foto(uid)},
        "resumo": resumo[uid],
        "equipe": metrics.media_equipe(resumo, ativos),
        "status": m["status_geral"],
        "sla": m["sla_geral"],
        "evolucao": m["evolucao"],
        "sla_expirado": m["tabela_sla_expirado"],
        "em_aberto": metrics.linhas_em_aberto(dados, uid),
        "ranking": {"posicao": meu["posicao"], "pontuacao": meu["pontuacao"], "total": len(rk["ranking"])}
        if meu else {"posicao": None, "total": len(rk["ranking"]), "minimo": rk["minimo"],
                     "atendidos": next((p["atendidos"] for p in rk["poucos"] if p["id"] == uid), 0)},
    }


@app.get("/api/tecnico/{uid}/foto")
def api_foto(uid: int, _: dict = Depends(usuario_atual)):
    caminho = caminho_foto(uid)
    if not os.path.exists(caminho):
        raise HTTPException(404, "Sem foto.")
    return FileResponse(caminho, media_type="image/jpeg", headers={"Cache-Control": "no-cache"})


@app.post("/api/tecnico/{uid}/foto")
def api_foto_salvar(uid: int, corpo: dict, _: dict = Depends(somente_admin)):
    imagem = str(corpo.get("image", ""))
    prefixo = "data:image/jpeg;base64,"
    if not imagem.startswith(prefixo):
        raise HTTPException(400, "Formato de imagem inválido.")
    try:
        binario = base64.b64decode(imagem[len(prefixo):], validate=True)
    except ValueError:
        raise HTTPException(400, "Imagem corrompida.")
    if len(binario) > 2 * 1024 * 1024 or not binario.startswith(b"\xff\xd8"):
        raise HTTPException(400, "A imagem precisa ser JPEG com até 2 MB.")
    os.makedirs(FOTOS, exist_ok=True)
    tmp = caminho_foto(uid) + ".tmp"
    with open(tmp, "wb") as f:
        f.write(binario)
    os.replace(tmp, caminho_foto(uid))
    return {"ok": True, "foto": versao_foto(uid)}


@app.delete("/api/tecnico/{uid}/foto")
def api_foto_remover(uid: int, _: dict = Depends(somente_admin)):
    try:
        os.remove(caminho_foto(uid))
    except FileNotFoundError:
        pass
    return {"ok": True}
