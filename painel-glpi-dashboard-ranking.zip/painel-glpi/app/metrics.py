"""Definicao e calculo das metricas do painel."""
from collections import defaultdict
from datetime import datetime

STATUS = {1: "Novo", 2: "Em atendimento", 3: "Planejado", 4: "Pendente",
          5: "Aguardando aprovação", 6: "Fechado"}

# kind: series (1 serie), multi (varias series), kpi (numero), table (tabela)
METRICS = [
    # Indicadores (cartoes)
    {"id": "kpi_abertos", "group": "Indicadores", "kind": "kpi", "title": "Abertos no período",
     "help": "Chamados abertos no período selecionado."},
    {"id": "kpi_em_aberto", "group": "Indicadores", "kind": "kpi", "title": "Em aberto agora",
     "help": "Chamados não solucionados neste momento (ignora o período)."},
    {"id": "kpi_pendentes", "group": "Indicadores", "kind": "kpi", "title": "Pendentes agora",
     "help": "Chamados com status Pendente neste momento (ignora o período)."},
    {"id": "kpi_aguardando", "group": "Indicadores", "kind": "kpi", "title": "Aguardando aprovação",
     "help": "Chamados solucionados aguardando aprovação do cliente (ignora o período)."},
    {"id": "kpi_sla_expirado", "group": "Indicadores", "kind": "kpi", "title": "SLA expirado (em aberto)",
     "help": "Chamados em aberto com prazo de solução vencido (ignora o período)."},
    {"id": "kpi_fechados", "group": "Indicadores", "kind": "kpi", "title": "Fechados no período",
     "help": "Chamados fechados dentro do período."},
    {"id": "kpi_reabertos", "group": "Indicadores", "kind": "kpi", "title": "Reabertos",
     "help": "Chamados abertos no período com solução recusada pelo cliente."},
    {"id": "kpi_sla_percentual", "group": "Indicadores", "kind": "kpi", "title": "SLA cumprido",
     "help": "% de chamados solucionados no período dentro do prazo de solução."},
    {"id": "kpi_tempo_medio", "group": "Indicadores", "kind": "kpi", "title": "Tempo médio de solução",
     "help": "Média em horas úteis (calendário do GLPI) dos chamados solucionados no período."},
    {"id": "kpi_novos_sem_tecnico", "group": "Indicadores", "kind": "kpi", "title": "Novos sem técnico",
     "help": "Chamados novos ainda sem técnico atribuído (ignora filtros)."},

    # Visao geral
    {"id": "status_geral", "group": "Visão geral", "kind": "series", "title": "Chamados por status",
     "help": "Chamados abertos no período, agrupados pelo status atual."},
    {"id": "sla_geral", "group": "Visão geral", "kind": "series", "title": "Situação do SLA",
     "help": "Chamados abertos no período, agrupados pela situação do prazo de solução."},
    {"id": "evolucao", "group": "Visão geral", "kind": "multi", "title": "Abertos x Solucionados x Fechados",
     "help": "Evolução diária (ou mensal, em períodos acima de 2 meses)."},

    # Por tecnico
    {"id": "status_por_tecnico", "group": "Por técnico", "kind": "multi", "title": "Status por técnico",
     "help": "Chamados abertos no período, por técnico e status atual."},
    {"id": "em_aberto_por_tecnico", "group": "Por técnico", "kind": "series", "title": "Em aberto por técnico",
     "help": "Fila atual de cada técnico (ignora o período)."},
    {"id": "pendentes_por_tecnico", "group": "Por técnico", "kind": "series", "title": "Pendentes por técnico",
     "help": "Chamados Pendentes agora (ignora o período)."},
    {"id": "aguardando_por_tecnico", "group": "Por técnico", "kind": "series",
     "title": "Aguardando aprovação por técnico",
     "help": "Solucionados aguardando aprovação do cliente (ignora o período)."},
    {"id": "fechados_por_tecnico", "group": "Por técnico", "kind": "series", "title": "Fechados por técnico",
     "help": "Chamados fechados dentro do período."},
    {"id": "reabertos_por_tecnico", "group": "Por técnico", "kind": "series", "title": "Reabertos por técnico",
     "help": "Chamados abertos no período com solução recusada."},
    {"id": "sla_por_tecnico", "group": "Por técnico", "kind": "multi", "title": "SLA por técnico",
     "help": "Chamados com SLA abertos no período: no prazo x expirado."},
    {"id": "sla_percentual_por_tecnico", "group": "Por técnico", "kind": "series",
     "title": "% SLA cumprido por técnico",
     "help": "% de solucionados no período dentro do prazo."},
    {"id": "tempo_medio_por_tecnico", "group": "Por técnico", "kind": "series",
     "title": "Tempo médio de solução (h) por técnico",
     "help": "Média em horas úteis dos chamados solucionados no período."},
    {"id": "validacoes_por_tecnico", "group": "Por técnico", "kind": "series",
     "title": "Aguardando validação por técnico",
     "help": "Chamados em aberto com validação (aprovação de gestor) pendente."},

    # Pendencias (situacao atual: ignoram o periodo)
    {"id": "kpi_pendencia_media", "group": "Pendências", "kind": "kpi", "title": "Tempo médio em pendência",
     "help": "Média de há quanto tempo os chamados pendentes estão parados (ignora o período)."},
    {"id": "kpi_pendencia_maior", "group": "Pendências", "kind": "kpi", "title": "Maior tempo em pendência",
     "help": "O chamado pendente há mais tempo (ignora o período)."},
    {"id": "kpi_pendencia_total", "group": "Pendências", "kind": "kpi", "title": "Soma do tempo em pendência",
     "help": "Soma do tempo parado de todos os chamados pendentes agora (ignora o período)."},
    {"id": "kpi_pendentes_7dias", "group": "Pendências", "kind": "kpi", "title": "Pendentes há mais de 7 dias",
     "help": "Quantidade de chamados pendentes há mais de 7 dias (ignora o período)."},
    {"id": "pendencia_faixas", "group": "Pendências", "kind": "series", "title": "Pendentes por tempo parado",
     "help": "Chamados pendentes agrupados por há quanto tempo estão em pendência."},
    {"id": "pendencia_soma_por_tecnico", "group": "Pendências", "kind": "series",
     "title": "Soma do tempo em pendência por técnico (dias)",
     "help": "Soma, em dias, do tempo parado dos chamados pendentes de cada técnico."},
    {"id": "pendencia_media_por_tecnico", "group": "Pendências", "kind": "series",
     "title": "Tempo médio em pendência por técnico (dias)",
     "help": "Média, em dias, do tempo parado dos chamados pendentes de cada técnico."},
    {"id": "tabela_pendencia_tecnico", "group": "Pendências", "kind": "table",
     "title": "Pendências por técnico",
     "help": "Quantidade, soma, média e maior tempo em pendência dos chamados pendentes de cada técnico."},
    {"id": "tabela_pendentes", "group": "Pendências", "kind": "table", "title": "Chamados pendentes",
     "help": "Chamados pendentes agora, do parado há mais tempo ao mais recente."},

    # Ranking de tecnicos (pontuacao: SLA, reaberturas e tempo em pendencia)
    {"id": "ranking_tecnicos", "group": "Ranking", "kind": "table", "title": "Ranking de técnicos",
     "help": "Pontuação de 0 a 100 sobre os chamados atendidos no período (solucionados ou reabertos): "
             "SLA cumprido, menos reaberturas, menos tempo em pendência e menor tempo de solução. "
             "Pesos e limites em Configurações."},
    {"id": "ranking_pontuacao", "group": "Ranking", "kind": "series", "title": "Pontuação do ranking",
     "help": "Pontuação de cada técnico no ranking (0 a 100), do primeiro ao último colocado."},
    {"id": "ranking_notas", "group": "Ranking", "kind": "multi", "title": "Composição da pontuação",
     "help": "Nota (0 a 100) de cada técnico em SLA, reaberturas, pendência e tempo de solução, "
             "na ordem do ranking."},

    # Tabelas
    {"id": "tabela_ranking", "group": "Tabelas", "kind": "table", "title": "Resumo por técnico",
     "help": "Principais indicadores de cada técnico."},
    {"id": "tabela_sla_expirado", "group": "Tabelas", "kind": "table", "title": "Chamados com SLA expirado",
     "help": "Chamados em aberto com prazo vencido, do mais atrasado ao menos atrasado."},
]

SLA_ORDEM = ["Solucionado no prazo", "Em aberto - no prazo", "Solucionado fora do prazo",
             "Em aberto - expirado", "Sem SLA"]


# Motivos de um chamado estar "Sem SLA" (sem prazo de solucao), do mais ao menos acionavel
SEM_SLA_SEM_CATEGORIA = "Sem categoria"
SEM_SLA_CATEGORIA = "Categoria sem SLA configurado"
SEM_SLA_NAO_APLICADO = "Categoria com SLA, mas não aplicado"
SEM_SLA_SEM_PRAZO = "SLA atribuído sem prazo calculado"
EXPLICACAO_SEM_SLA = {
    SEM_SLA_SEM_CATEGORIA: "(regras de SLA costumam usar a categoria)",
    SEM_SLA_CATEGORIA: "(nenhum chamado delas recebeu SLA)",
    SEM_SLA_NAO_APLICADO: "(aberto antes da regra, categoria trocada ou SLA removido)",
    SEM_SLA_SEM_PRAZO: "(confira o calendário do SLA no GLPI)",
}


def _categorias_com_sla(dados):
    """Categorias em que algum chamado recebeu SLA (calculado uma vez por leitura do GLPI)."""
    if "_categorias_com_sla" not in dados:
        dados["_categorias_com_sla"] = {t.get("categoria") for t in dados["tickets"]
                                        if t.get("categoria") and (t["ttr"] or t.get("sla_ttr"))}
    return dados["_categorias_com_sla"]


def motivo_sem_sla(t, dados):
    """Motivo provavel de o chamado nao ter prazo de solucao (ou None se ele tem)."""
    if t["ttr"] is not None:
        return None
    if t.get("sla_ttr"):
        return SEM_SLA_SEM_PRAZO
    cat = t.get("categoria")
    if not cat:
        return SEM_SLA_SEM_CATEGORIA
    return SEM_SLA_NAO_APLICADO if cat in _categorias_com_sla(dados) else SEM_SLA_CATEGORIA


def _curto(texto, limite=32):
    """Encurta 'A > B > C > D' mantendo o fim, que e a parte mais especifica da categoria."""
    if len(texto) <= limite:
        return texto
    partes = [p.strip() for p in texto.split(">")]
    fim = partes.pop()
    while partes and len(partes[-1]) + len(fim) + 5 <= limite:
        fim = f"{partes.pop()} > {fim}"
    return ("… > " + fim) if len(fim) <= limite - 4 else "…" + fim[-(limite - 1):]


def detalhes_sem_sla(chamados, dados, top=3):
    """Linhas para o balao do grafico: quantos chamados por motivo e as categorias mais frequentes."""
    nomes = dados.get("categorias", {})
    por_motivo = defaultdict(lambda: defaultdict(int))
    for t in chamados:
        m = motivo_sem_sla(t, dados)
        if m:
            por_motivo[m][t.get("categoria") or 0] += 1
    if not por_motivo:
        return []
    linhas = ["Por que estão sem SLA:"]
    for m in (SEM_SLA_CATEGORIA, SEM_SLA_NAO_APLICADO, SEM_SLA_SEM_CATEGORIA, SEM_SLA_SEM_PRAZO):
        cats = por_motivo.get(m)
        if not cats:
            continue
        linhas.append(f"• {m}: {sum(cats.values())}")
        linhas.append(f"   {EXPLICACAO_SEM_SLA[m]}")
        if m != SEM_SLA_SEM_CATEGORIA:
            maiores = sorted(((c, n) for c, n in cats.items() if c), key=lambda x: -x[1])
            for c, n in maiores[:top]:
                linhas.append(f"   – {_curto(nomes.get(c, f'Categoria {c}'))}: {n}")
            if len(maiores) > top:
                linhas.append(f"   – e mais {len(maiores) - top} categoria(s)")
    return linhas


def _fmt(dt):
    return dt.strftime("%d/%m/%Y %H:%M") if dt else ""


FAIXAS_PENDENCIA = [(86400, "Até 1 dia"), (3 * 86400, "1 a 3 dias"), (7 * 86400, "3 a 7 dias"),
                    (15 * 86400, "7 a 15 dias"), (30 * 86400, "15 a 30 dias"), (None, "Mais de 30 dias")]


def duracao_txt(segundos):
    """Ex.: 3d 4h, 5h 20min, 12min."""
    if segundos is None:
        return "–"
    segundos = max(0, int(segundos))
    dias, resto = divmod(segundos, 86400)
    horas, resto = divmod(resto, 3600)
    minutos = resto // 60
    if dias:
        return f"{dias}d {horas}h"
    if horas:
        return f"{horas}h {minutos}min"
    return f"{minutos}min"


def em_dias(segundos):
    return round(segundos / 86400, 1)


def tempo_pendente(t, agora):
    """Ha quanto tempo o chamado esta no periodo de pendencia atual (tempo corrido)."""
    if t["status"] != 4 or t.get("begin_waiting") is None:
        return None
    return max(0, (agora - t["begin_waiting"]).total_seconds())


def _media_horas(valores):
    valores = [v for v in valores if v > 0]
    return round(sum(valores) / len(valores) / 3600, 1) if valores else 0


def _chaves_tempo(inicio, fim):
    mensal = (fim.date() - inicio.date()).days > 62
    chaves, rotulos = [], []
    if mensal:
        ano, mes = inicio.year, inicio.month
        while (ano, mes) <= (fim.year, fim.month):
            chaves.append(f"{ano:04d}-{mes:02d}")
            rotulos.append(f"{mes:02d}/{ano}")
            mes += 1
            if mes > 12:
                ano, mes = ano + 1, 1
        return chaves, rotulos, (lambda dt: dt.strftime("%Y-%m"))
    dia = inicio.date()
    while dia <= fim.date():
        chaves.append(dia.isoformat())
        rotulos.append(dia.strftime("%d/%m"))
        dia = dia.fromordinal(dia.toordinal() + 1)
    return chaves, rotulos, (lambda dt: dt.date().isoformat())


RANKING_PADRAO = {
    "rk_peso_sla": 40,          # peso do SLA cumprido
    "rk_peso_reab": 20,         # peso de "menos reaberturas"
    "rk_peso_pend": 20,         # peso de "menos tempo em pendencia"
    "rk_peso_sol": 20,          # peso de "menor tempo de solucao"
    "rk_limite_reab": 20,       # % de reabertura que zera a nota de reaberturas
    "rk_limite_pend_h": 72,     # horas medias em pendencia por chamado que zeram a nota de pendencia
    "rk_limite_sol_h": 48,      # horas medias de solucao que zeram a nota de tempo de solucao
    "rk_minimo": 5,             # chamados atendidos no periodo para entrar no ranking
}
MEDALHAS = {1: "🥇", 2: "🥈", 3: "🥉"}


def _no(dt, inicio, fim):
    return dt is not None and inicio <= dt <= fim


def ranking(dados, inicio, fim, filtro_tecnicos=None, cfg=None):
    """Classifica os tecnicos ativos pelos chamados atendidos no periodo.

    Atendidos = chamados do tecnico solucionados no periodo ou com solucao recusada (reabertos)
    no periodo. Notas de 0 a 100:
      * SLA: % dos solucionados com prazo cumpridos dentro do prazo;
      * Reaberturas: 100 - taxa de reabertura x 100 / limite (limite padrao 20% => nota 0);
      * Pendencia: 100 - horas medias em pendencia por chamado x 100 / limite (padrao 72 h => nota 0);
      * Tempo de solucao: 100 - media de horas de solucao x 100 / limite (padrao 48 h => nota 0).
        Usa o tempo de solucao do GLPI (solve_delay_stat: calendario do SLA, sem o tempo em pendencia).
    Pontuacao = media ponderada das notas (criterio sem dados no periodo fica de fora).
    """
    c = dict(RANKING_PADRAO)
    c.update({k: v for k, v in (cfg or {}).items() if k in RANKING_PADRAO and v is not None})
    pesos = {"sla": float(c["rk_peso_sla"]), "reab": float(c["rk_peso_reab"]), "pend": float(c["rk_peso_pend"]),
             "sol": float(c["rk_peso_sol"])}
    lim_reab = max(1.0, float(c["rk_limite_reab"]))
    lim_pend = max(1.0, float(c["rk_limite_pend_h"]))
    lim_sol = max(1.0, float(c["rk_limite_sol_h"]))
    minimo = max(1, int(c["rk_minimo"]))

    agora = datetime.now()
    tecnicos = dados["techs"]
    sel = (set(filtro_tecnicos) & set(tecnicos)) if filtro_tecnicos else set(tecnicos)
    sel = {u for u in sel if tecnicos[u]["active"]}
    por_tec = defaultdict(list)
    for t in dados["tickets"]:
        for u in t["techs"] & sel:
            por_tec[u].append(t)

    classificados, poucos = [], []
    for u in sel:
        T = por_tec[u]
        solucionados = [t for t in T if t["status"] in (5, 6) and _no(t["solvedate"], inicio, fim)]
        reabertos = [t for t in T if t["refused"] and (
            _no(t.get("refused_date"), inicio, fim)
            or (t.get("refused_date") is None and _no(t["date"], inicio, fim)))]
        base = {t["id"]: t for t in solucionados + reabertos}
        n = len(base)
        item = {"id": u, "name": tecnicos[u]["name"], "atendidos": n}
        if n < minimo:
            poucos.append(item)
            continue
        com_sla = [t for t in solucionados if t["ttr"]]
        no_prazo = sum(1 for t in com_sla if t["solvedate"] <= t["ttr"])
        sla_pct = round(100 * no_prazo / len(com_sla), 1) if com_sla else None
        taxa_reab = 100 * len(reabertos) / n
        pend_seg = sum(t.get("waiting_duration", 0) + (tempo_pendente(t, agora) or 0) for t in base.values())
        pend_media_h = pend_seg / n / 3600
        tempos_sol = [t["solve_delay"] for t in solucionados if t["solve_delay"] > 0]
        sol_media_h = sum(tempos_sol) / len(tempos_sol) / 3600 if tempos_sol else None
        notas = {
            "sla": sla_pct,
            "reab": max(0.0, 100 - taxa_reab * 100 / lim_reab),
            "pend": max(0.0, 100 - pend_media_h * 100 / lim_pend),
            "sol": None if sol_media_h is None else max(0.0, 100 - sol_media_h * 100 / lim_sol),
        }
        usados = {k: pesos[k] for k in notas if notas[k] is not None and pesos[k] > 0}
        soma = sum(usados.values())
        pontos = round(sum(notas[k] * w for k, w in usados.items()) / soma, 1) if soma else 0.0
        item.update({
            "pontuacao": pontos, "sla_pct": sla_pct, "com_sla": len(com_sla), "no_prazo": no_prazo,
            "solucionados": len(solucionados), "reabertos": len(reabertos), "taxa_reab": round(taxa_reab, 1),
            "pend_media_h": round(pend_media_h, 1), "pend_total_seg": pend_seg,
            "nota_sla": None if sla_pct is None else round(sla_pct, 1),
            "nota_reab": round(notas["reab"], 1), "nota_pend": round(notas["pend"], 1),
            "sol_media_h": None if sol_media_h is None else round(sol_media_h, 1),
            "nota_sol": None if notas["sol"] is None else round(notas["sol"], 1),
        })
        classificados.append(item)

    # desempate: SLA, menos reabertos, menos pendencia, solucao mais rapida, mais atendidos, nome
    sem_sol = float("inf")
    classificados.sort(key=lambda r: (-r["pontuacao"], -(r["sla_pct"] or 0), r["taxa_reab"], r["pend_media_h"],
                                      sem_sol if r["sol_media_h"] is None else r["sol_media_h"],
                                      -r["atendidos"], r["name"].lower()))
    anterior, pos = None, 0
    for i, r in enumerate(classificados, 1):
        chave = (r["pontuacao"], r["sla_pct"], r["taxa_reab"], r["pend_media_h"], r["sol_media_h"])
        if chave != anterior:
            pos, anterior = i, chave
        r["posicao"] = pos
    poucos.sort(key=lambda r: r["name"].lower())
    return {"ranking": classificados, "poucos": poucos, "minimo": minimo,
            "pesos": dict(pesos), "limites": {"reab": lim_reab, "pend_h": lim_pend, "sol_h": lim_sol}}


def calcular(dados, inicio, fim, filtro_tecnicos, cfg_ranking=None):
    agora = datetime.now()
    tecnicos = dados["techs"]
    sel = (set(filtro_tecnicos) & set(tecnicos)) if filtro_tecnicos else set(tecnicos)
    nomes = {u: tecnicos[u]["name"] for u in sel}
    ordem = sorted(sel, key=lambda u: nomes[u].lower())
    rot_tec = [nomes[u] for u in ordem]

    T = [t for t in dados["tickets"] if t["techs"] & sel]

    def no_periodo(dt):
        return dt is not None and inicio <= dt <= fim

    abertos = [t for t in T if no_periodo(t["date"])]
    solucionados = [t for t in T if t["status"] in (5, 6) and no_periodo(t["solvedate"])]
    fechados = [t for t in T if t["status"] == 6 and no_periodo(t["closedate"])]
    em_aberto = [t for t in T if t["status"] not in (5, 6)]

    def por_tecnico(lista, cond=lambda t: True):
        c = defaultdict(int)
        for t in lista:
            if cond(t):
                for u in t["techs"] & sel:
                    c[u] += 1
        return [c[u] for u in ordem]

    def serie(rotulos, valores, nome="Chamados"):
        return {"labels": rotulos, "datasets": [{"label": nome, "data": valores}]}

    def multi(rotulos, series):
        return {"labels": rotulos, "datasets": [{"label": n, "data": v} for n, v in series]}

    def situacao_sla(t):
        if t["ttr"] is None:
            return "Sem SLA"
        if t["status"] in (5, 6):
            ok = t["solvedate"] is not None and t["solvedate"] <= t["ttr"]
            return "Solucionado no prazo" if ok else "Solucionado fora do prazo"
        return "Em aberto - expirado" if agora > t["ttr"] else "Em aberto - no prazo"

    def sla_ok(t):
        return situacao_sla(t) in ("Solucionado no prazo", "Em aberto - no prazo")

    def pct_sla(lista):
        com = [t for t in lista if t["ttr"]]
        if not com:
            return None
        return round(100 * sum(1 for t in com if t["solvedate"] <= t["ttr"]) / len(com), 1)

    m = {}

    # ---------- Indicadores ----------
    m["kpi_abertos"] = {"value": len(abertos)}
    m["kpi_em_aberto"] = {"value": len(em_aberto)}
    m["kpi_pendentes"] = {"value": sum(1 for t in T if t["status"] == 4)}
    m["kpi_aguardando"] = {"value": sum(1 for t in T if t["status"] == 5)}
    m["kpi_sla_expirado"] = {"value": sum(1 for t in em_aberto if t["ttr"] and agora > t["ttr"])}
    m["kpi_fechados"] = {"value": len(fechados)}
    m["kpi_reabertos"] = {"value": sum(1 for t in abertos if t["refused"])}
    m["kpi_sla_percentual"] = {"value": pct_sla(solucionados), "suffix": "%"}
    m["kpi_tempo_medio"] = {"value": _media_horas([t["solve_delay"] for t in solucionados]), "suffix": " h"}
    m["kpi_novos_sem_tecnico"] = {"value": dados["unassigned_new"]}

    # ---------- Visao geral ----------
    cont = defaultdict(int)
    for t in abertos:
        cont[t["status"]] += 1
    st = [s for s in STATUS if cont[s]]
    m["status_geral"] = serie([STATUS[s] for s in st], [cont[s] for s in st])

    cont_sla = defaultdict(int)
    for t in abertos:
        cont_sla[situacao_sla(t)] += 1
    sl = [s for s in SLA_ORDEM if cont_sla[s]]
    m["sla_geral"] = serie(sl, [cont_sla[s] for s in sl])
    if cont_sla["Sem SLA"]:
        m["sla_geral"]["details"] = {"Sem SLA": detalhes_sem_sla(abertos, dados)}

    chaves, rotulos, chave = _chaves_tempo(inicio, fim)
    a, s, f = defaultdict(int), defaultdict(int), defaultdict(int)
    for t in abertos:
        a[chave(t["date"])] += 1
    for t in solucionados:
        s[chave(t["solvedate"])] += 1
    for t in fechados:
        f[chave(t["closedate"])] += 1
    m["evolucao"] = multi(rotulos, [("Abertos", [a[k] for k in chaves]),
                                    ("Solucionados", [s[k] for k in chaves]),
                                    ("Fechados", [f[k] for k in chaves])])

    # ---------- Por tecnico ----------
    m["status_por_tecnico"] = multi(rot_tec, [
        ("Em atendimento", por_tecnico(abertos, lambda t: t["status"] in (1, 2, 3))),
        ("Pendentes", por_tecnico(abertos, lambda t: t["status"] == 4)),
        ("Aguardando aprovação", por_tecnico(abertos, lambda t: t["status"] == 5)),
        ("Fechados", por_tecnico(abertos, lambda t: t["status"] == 6)),
    ])
    m["em_aberto_por_tecnico"] = serie(rot_tec, por_tecnico(em_aberto), "Em aberto")
    m["pendentes_por_tecnico"] = serie(rot_tec, por_tecnico(T, lambda t: t["status"] == 4), "Pendentes")
    m["aguardando_por_tecnico"] = serie(rot_tec, por_tecnico(T, lambda t: t["status"] == 5),
                                        "Aguardando aprovação")
    m["fechados_por_tecnico"] = serie(rot_tec, por_tecnico(fechados), "Fechados")
    m["reabertos_por_tecnico"] = serie(rot_tec, por_tecnico(abertos, lambda t: t["refused"]), "Reabertos")

    com_sla = [t for t in abertos if t["ttr"]]
    m["sla_por_tecnico"] = multi(rot_tec, [
        ("No prazo", por_tecnico(com_sla, sla_ok)),
        ("Expirado", por_tecnico(com_sla, lambda t: not sla_ok(t))),
    ])
    m["sla_percentual_por_tecnico"] = serie(
        rot_tec, [pct_sla([t for t in solucionados if u in t["techs"]]) or 0 for u in ordem],
        "% SLA cumprido")
    m["tempo_medio_por_tecnico"] = serie(
        rot_tec, [_media_horas([t["solve_delay"] for t in solucionados if u in t["techs"]]) for u in ordem],
        "Horas (média)")
    m["validacoes_por_tecnico"] = serie(
        rot_tec, por_tecnico(em_aberto, lambda t: t["waiting_validation"]), "Aguardando validação")

    # ---------- Tabelas ----------
    linhas = []
    for u in ordem:
        ab = [t for t in abertos if u in t["techs"]]
        so = [t for t in solucionados if u in t["techs"]]
        p = pct_sla(so)
        linhas.append([
            nomes[u],
            len(ab),
            sum(1 for t in fechados if u in t["techs"]),
            sum(1 for t in em_aberto if u in t["techs"]),
            sum(1 for t in T if u in t["techs"] and t["status"] == 4),
            sum(1 for t in T if u in t["techs"] and t["status"] == 5),
            sum(1 for t in ab if t["refused"]),
            "-" if p is None else f"{p}%",
            _media_horas([t["solve_delay"] for t in so]),
        ])
    m["tabela_ranking"] = {
        "columns": ["Técnico", "Abertos (período)", "Fechados (período)", "Em aberto agora",
                    "Pendentes", "Aguard. aprovação", "Reabertos", "SLA cumprido", "Tempo médio (h)"],
        "rows": linhas,
    }

    # ---------- Ranking ----------
    rk = ranking(dados, inicio, fim, filtro_tecnicos, cfg_ranking)
    m["ranking_tecnicos"] = {
        "columns": ["Posição", "Técnico", "Pontuação", "Atendidos", "SLA cumprido", "Reabertos", "% reabertos",
                    "Pendência média (h)", "Solução média (h)", "Nota SLA", "Nota reabertura",
                    "Nota pendência", "Nota solução"],
        "rows": [[r["posicao"], f"{MEDALHAS.get(r['posicao'], '')} {r['name']}".strip(), r["pontuacao"],
                  r["atendidos"], "–" if r["sla_pct"] is None else f"{r['sla_pct']}%", r["reabertos"],
                  f"{r['taxa_reab']}%", r["pend_media_h"], "–" if r["sol_media_h"] is None else r["sol_media_h"],
                  "–" if r["nota_sla"] is None else r["nota_sla"], r["nota_reab"], r["nota_pend"],
                  "–" if r["nota_sol"] is None else r["nota_sol"]] for r in rk["ranking"]],
    }
    rot_rk = [r["name"] for r in rk["ranking"]]
    m["ranking_pontuacao"] = serie(rot_rk, [r["pontuacao"] for r in rk["ranking"]], "Pontuação")
    m["ranking_notas"] = multi(rot_rk, [
        ("Nota SLA", [r["nota_sla"] or 0 for r in rk["ranking"]]),
        ("Nota reabertura", [r["nota_reab"] for r in rk["ranking"]]),
        ("Nota pendência", [r["nota_pend"] for r in rk["ranking"]]),
        ("Nota solução", [r["nota_sol"] or 0 for r in rk["ranking"]]),
    ])

    # ---------- Pendencias ----------
    pendentes = [(t, tempo_pendente(t, agora)) for t in T if t["status"] == 4]
    tempos = [s for _, s in pendentes if s is not None]
    media = sum(tempos) / len(tempos) if tempos else None
    m["kpi_pendencia_media"] = {"value": em_dias(media) if media is not None else None, "suffix": " dias",
                                "text": duracao_txt(media) if media is not None else None}
    maior = max(tempos) if tempos else None
    m["kpi_pendencia_maior"] = {"value": em_dias(maior) if maior is not None else None, "suffix": " dias",
                                "text": duracao_txt(maior) if maior is not None else None}
    total = sum(tempos)
    m["kpi_pendencia_total"] = {"value": em_dias(total), "suffix": " dias", "text": duracao_txt(total)}
    m["kpi_pendentes_7dias"] = {"value": sum(1 for s in tempos if s > 7 * 86400)}

    faixas = defaultdict(int)
    for s_ in tempos:
        for limite, nome in FAIXAS_PENDENCIA:
            if limite is None or s_ <= limite:
                faixas[nome] += 1
                break
    m["pendencia_faixas"] = serie([n for _, n in FAIXAS_PENDENCIA], [faixas[n] for _, n in FAIXAS_PENDENCIA],
                                  "Chamados pendentes")

    por_tec = defaultdict(list)
    for t, s_ in pendentes:
        for u in t["techs"] & sel:
            if s_ is not None:
                por_tec[u].append(s_)
    m["pendencia_soma_por_tecnico"] = serie(rot_tec, [em_dias(sum(por_tec[u])) for u in ordem], "Dias em pendência")
    m["pendencia_media_por_tecnico"] = serie(
        rot_tec, [em_dias(sum(por_tec[u]) / len(por_tec[u])) if por_tec[u] else 0 for u in ordem],
        "Média em dias")

    linhas_tec = []
    for u in sorted(ordem, key=lambda x: -sum(por_tec[x])):
        lista = por_tec[u]
        qtd = sum(1 for t, _ in pendentes if u in t["techs"])
        if not qtd:
            continue
        linhas_tec.append([nomes[u], qtd, duracao_txt(sum(lista)), em_dias(sum(lista)),
                           duracao_txt(sum(lista) / len(lista)) if lista else "–",
                           duracao_txt(max(lista)) if lista else "–",
                           sum(1 for x in lista if x > 7 * 86400)])
    m["tabela_pendencia_tecnico"] = {
        "columns": ["Técnico", "Pendentes", "Soma do tempo", "Soma (dias)", "Tempo médio", "Maior tempo",
                    "Há mais de 7 dias"],
        "rows": linhas_tec,
    }

    ordenados = sorted(pendentes, key=lambda x: -(x[1] or 0))
    m["tabela_pendentes"] = {
        "columns": ["Chamado", "Título", "Técnico(s)", "Pendente desde", "Tempo pendente",
                    "Total já pendente", "Prazo SLA"],
        "rows": [[t["id"], t["name"], ", ".join(sorted(nomes[u] for u in t["techs"] & sel)),
                  _fmt(t["begin_waiting"]), duracao_txt(s_),
                  duracao_txt((s_ or 0) + t.get("waiting_duration", 0)), _fmt(t["ttr"])]
                 for t, s_ in ordenados[:500]],
    }

    atrasados = sorted([t for t in em_aberto if t["ttr"] and agora > t["ttr"]], key=lambda t: t["ttr"])
    m["tabela_sla_expirado"] = {
        "columns": ["Chamado", "Título", "Técnico(s)", "Status", "Abertura", "Prazo SLA", "Atraso (h)"],
        "rows": [[t["id"], t["name"], ", ".join(sorted(nomes[u] for u in t["techs"] & sel)),
                  STATUS.get(t["status"], ""), _fmt(t["date"]), _fmt(t["ttr"]),
                  round((agora - t["ttr"]).total_seconds() / 3600, 1)] for t in atrasados[:500]],
    }
    return m


COLUNAS_CHAMADOS = ["Chamado", "Título", "Status", "Técnico(s)", "Abertura", "Solução", "Fechamento",
                    "Prazo SLA", "Situação SLA", "Motivo sem SLA", "Categoria", "Reaberto", "Aguardando validação", "Tempo de solução (h)"]


def linhas_chamados(dados, inicio, fim, filtro_tecnicos):
    """Chamados abertos no periodo, um por linha, para exportacao em CSV."""
    agora = datetime.now()
    tecnicos = dados["techs"]
    sel = (set(filtro_tecnicos) & set(tecnicos)) if filtro_tecnicos else set(tecnicos)
    linhas = []
    for t in sorted(dados["tickets"], key=lambda x: x["id"]):
        if not (t["techs"] & sel) or t["date"] is None or not (inicio <= t["date"] <= fim):
            continue
        if t["ttr"] is None:
            sla = "Sem SLA"
        elif t["status"] in (5, 6):
            sla = "No prazo" if t["solvedate"] and t["solvedate"] <= t["ttr"] else "Expirado"
        else:
            sla = "Expirado" if agora > t["ttr"] else "No prazo"
        linhas.append([
            t["id"], t["name"], STATUS.get(t["status"], ""),
            ", ".join(sorted(tecnicos[u]["name"] for u in t["techs"] & sel)),
            _fmt(t["date"]), _fmt(t["solvedate"]), _fmt(t["closedate"]), _fmt(t["ttr"]), sla,
            motivo_sem_sla(t, dados) or "", dados.get("categorias", {}).get(t.get("categoria"), ""),
            "Sim" if t["refused"] else "Não", "Sim" if t["waiting_validation"] else "Não",
            round(t["solve_delay"] / 3600, 1) if t["solve_delay"] else "",
        ])
    return linhas


def resumo_por_tecnico(dados, inicio, fim):
    """Indicadores individuais de cada tecnico, usados na pagina 'Por tecnico' e na media da equipe."""
    agora = datetime.now()
    res = {}
    for uid in dados["techs"]:
        T = [t for t in dados["tickets"] if uid in t["techs"]]
        abertos = [t for t in T if t["date"] and inicio <= t["date"] <= fim]
        solucionados = [t for t in T if t["status"] in (5, 6) and t["solvedate"] and inicio <= t["solvedate"] <= fim]
        com_sla = [t for t in solucionados if t["ttr"]]
        res[uid] = {
            "abertos": len(abertos),
            "fechados": sum(1 for t in T if t["status"] == 6 and t["closedate"] and inicio <= t["closedate"] <= fim),
            "em_aberto": sum(1 for t in T if t["status"] not in (5, 6)),
            "pendentes": sum(1 for t in T if t["status"] == 4),
            "aguardando": sum(1 for t in T if t["status"] == 5),
            "reabertos": sum(1 for t in abertos if t["refused"]),
            "sla_expirado": sum(1 for t in T if t["status"] not in (5, 6) and t["ttr"] and agora > t["ttr"]),
            "sla_pct": round(100 * sum(1 for t in com_sla if t["solvedate"] <= t["ttr"]) / len(com_sla), 1) if com_sla else None,
            "tempo_medio": _media_horas([t["solve_delay"] for t in solucionados]),
            "pendencia_soma": sum(x for x in (tempo_pendente(t, agora) for t in T) if x is not None),
            "pendencia_maior": max((x for x in (tempo_pendente(t, agora) for t in T) if x is not None), default=None),
        }
    return res


def media_equipe(resumo, ids_ativos):
    """Media simples entre os tecnicos ativos (ignora indicadores sem dados)."""
    medias = {}
    for chave in ("abertos", "fechados", "em_aberto", "pendentes", "aguardando", "reabertos",
                  "sla_expirado", "sla_pct", "tempo_medio", "pendencia_soma", "pendencia_maior"):
        valores = [resumo[u][chave] for u in ids_ativos if u in resumo and resumo[u][chave] is not None]
        if chave == "tempo_medio":
            valores = [v for v in valores if v > 0]
        medias[chave] = round(sum(valores) / len(valores), 1) if valores else None
    return medias


def linhas_em_aberto(dados, uid):
    agora = datetime.now()
    linhas = []
    for t in sorted((t for t in dados["tickets"] if uid in t["techs"] and t["status"] not in (5, 6)),
                    key=lambda x: (x["ttr"] is None, x["ttr"] or x["date"] or agora)):
        if t["ttr"] is None:
            sla = "Sem SLA"
        else:
            sla = "Expirado" if agora > t["ttr"] else "No prazo"
        pend = tempo_pendente(t, agora)
        linhas.append([t["id"], t["name"], STATUS.get(t["status"], ""), _fmt(t["date"]), _fmt(t["ttr"]), sla,
                       duracao_txt(pend) if pend is not None else ""])
    return {"columns": ["Chamado", "Título", "Status", "Abertura", "Prazo SLA", "Situação SLA", "Pendente há"],
            "rows": linhas[:500]}
